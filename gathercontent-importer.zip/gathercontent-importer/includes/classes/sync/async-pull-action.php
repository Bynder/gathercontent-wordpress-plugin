<?php
namespace GatherContent\Importer\Sync;

class Async_Pull_Action extends Async_Base {
	protected $action = 'gc_pull_items';
}

<div class="tablenav-pages one-page">
	<span class="displaying-num"><span class="gc-item-count">{{ data.count }}</span> <?php _e( 'items', 'gathercontent-import' ); ?></span>
	<# if ( data.selected ) { #>
	<strong class="selected-num">| <span class="gc-item-count">{{ data.selected }}</span> <?php _e( 'selected', 'gathercontent-import' ); ?></strong>
	<# } #>
</div>
<br class="clear">

<span class="gc-status-color <# if ( '#ffffff' === data.status.color ) { #> gc-status-color-white<# } #>" style="background-color:{{ data.status.color }};" data-id="{{ data.status.id }}"></span>
<span class="gc-status-name">{{ data.status.name }}</span>

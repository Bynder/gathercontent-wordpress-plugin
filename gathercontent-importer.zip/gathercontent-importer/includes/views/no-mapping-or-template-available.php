<div class="notice error">
	<p><?php esc_html_e( 'Uh oh! We couldn\'t find a template and/or project! It\'s possible the GatherContent API is having issues.', 'gathercontent-import' ); ?></p>
</div>

<div class="notice notice-info is-dismissible">
	<p><?php printf( __( '<strong>NOTE:</strong> There can be only one %s per project template. You are editing an existing mapping (ID: %d).', 'gathercontent-import' ), $this->get( 'name' ), $this->get( 'id' ) ); ?></p>
</div>

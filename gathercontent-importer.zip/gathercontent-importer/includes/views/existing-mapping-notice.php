<div class="notice notice-info is-dismissible">
	<p><?php printf( __( '<strong>NOTE:</strong> There can be only one %1$s per project template. You are editing an existing mapping (ID: %2$d).', 'gathercontent-import' ), $this->get( 'name' ), $this->get( 'id' ) ); ?></p>
</div>
